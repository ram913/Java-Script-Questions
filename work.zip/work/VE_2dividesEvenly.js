const dividesEvenly = (dividend,divisor) => dividend % divisor === 0;
console.log(dividesEvenly(91,13));