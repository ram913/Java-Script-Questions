const addUp = (n) => n*(n+1)/2;

console.log(addUp(4));
console.log(addUp(13));
console.log(addUp(600));