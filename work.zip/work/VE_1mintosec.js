const convert = (minutes) => 60 * minutes;
console.log(convert(5));